var cameraStates = new Object();
var currentCameraState = null;
var targetCameraState = null;

var defaultCameraState;